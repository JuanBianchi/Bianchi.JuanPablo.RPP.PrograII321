
package bibliotecarecuperatorio;


public class PublicacionDuplicadaException extends RuntimeException {
    private static final String MESSAGE = "La publicacion ya esta en la biblioteca";
    
    public PublicacionDuplicadaException()
    {
        super(MESSAGE);
    }    
}
