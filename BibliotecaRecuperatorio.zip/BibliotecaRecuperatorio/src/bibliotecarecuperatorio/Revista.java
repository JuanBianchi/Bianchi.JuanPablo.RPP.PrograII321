
package bibliotecarecuperatorio;


public class Revista extends Publicacion implements Leible{
    
    private int numeroEdicion;
    
    public Revista(String titulo, String anioPublicacion, int numeroEdicion)
    {
        super(titulo, anioPublicacion);
        this.numeroEdicion = numeroEdicion;
                
    }
    
    @Override
    public void leer()
    {
        System.out.println("La revista " + this.getTitulo() + " esta siendo leida...");
    }

    @Override
    public String toString() {
        return  "[numeroEdicion=" + numeroEdicion + ']';
    }
    
    
}
