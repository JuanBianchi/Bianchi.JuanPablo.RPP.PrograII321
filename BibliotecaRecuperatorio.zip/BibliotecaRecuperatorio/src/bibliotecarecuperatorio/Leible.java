
package bibliotecarecuperatorio;


public interface Leible {
    void leer();
}
