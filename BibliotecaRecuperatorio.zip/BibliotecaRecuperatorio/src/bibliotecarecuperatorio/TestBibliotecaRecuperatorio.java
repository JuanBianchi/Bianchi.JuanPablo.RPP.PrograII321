
package bibliotecarecuperatorio;


public class TestBibliotecaRecuperatorio {

    
    public static void main(String[] args) {
    
        Biblioteca yenny = new Biblioteca();
        
        Libro libro1 = new Libro("La iliada", "1000 AC", "Homero", Genero.FICCION);
        Libro libro2 = new Libro("IT", "1977", "Stephen King", Genero.FICCION);
        Libro libro3 = new Libro("El Sistema Solar", "2021", "Jose Gandara", Genero.CIENCIA);
        
        Revista revista1 = new Revista("CARAS", "1998", 2203);
        Revista revista2 = new Revista("Billiken", "2005", 11203);
        
        Ilustracion ilustracion1 = new Ilustracion("La Gioconda", "1400", "Da Vinci", 125, 105);
        
        //Libro libro4 = new Libro("El Sistema Solar", "2021", "Jose Gandara", Genero.CIENCIA);

        
        try{
            yenny.agregarPublicacion(libro1);
            yenny.agregarPublicacion(libro2);
            yenny.agregarPublicacion(libro3);
            yenny.agregarPublicacion(revista1);
            yenny.agregarPublicacion(revista2);
            yenny.agregarPublicacion(ilustracion1);
            //yenny.agregarPublicacion(libro1); DUPLICADO distinto nombre y año
            //yenny.agregarPublicacion(revista1); DUPLICADO distinto nombre y año
            //yenny.agregarPublicacion(libro4); DUPLICADO mismo nombre y año
            
            yenny.mostrarPublicacion();
            yenny.leerPublicaciones();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        
    }
    
}
