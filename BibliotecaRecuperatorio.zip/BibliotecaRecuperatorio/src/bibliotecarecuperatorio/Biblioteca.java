
package bibliotecarecuperatorio;

import java.util.ArrayList;
import java.util.List;


public class Biblioteca {
    
    private List<Publicacion> publicaciones;
    
    public Biblioteca(){
        this.publicaciones = new ArrayList<>();
    }
    
    public void agregarPublicacion(Publicacion publicacion)
    {
        if(publicacion == null)
        {
            throw new NullPointerException("Error. Esto no es una publicacion, es null.");
        }
        if(publicaciones.contains(publicacion))
        {
            throw new PublicacionDuplicadaException();
        }
        
        publicaciones.add(publicacion);
    }
    
    public void mostrarPublicacion()
    {
        for(Publicacion publi : publicaciones)
        {
            System.out.println(publi);
        }
    }
    
    public void leerPublicaciones()
    {
        for(Publicacion publi : publicaciones)
        {
            if(publi instanceof Leible publicacionLeible)
            {
                publicacionLeible.leer();
            }
            else
            {
                System.out.println(publi.getTitulo() + " no puede ser leida");
            }
        }
        
    }

    @Override
    public String toString() {
        return "Biblioteca{" + "publicaciones=" + publicaciones + '}';
    }
    
    
}
