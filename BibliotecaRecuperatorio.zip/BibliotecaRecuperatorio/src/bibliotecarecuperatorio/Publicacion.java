
package bibliotecarecuperatorio;

import java.util.Objects;


public abstract class Publicacion {
    
    private String titulo;
    private String anioPublicacion;
    
    public Publicacion(String titulo, String anioPublicacion)
    {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }
    
    public String getTitulo()
    {
        return this.titulo;
    }

    @Override
    public String toString() {
        return "Publicacion{" + "titulo=" + titulo + ", anioPublicacion=" + anioPublicacion + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.titulo);
        hash = 67 * hash + Objects.hashCode(this.anioPublicacion);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        
        Publicacion p = (Publicacion) obj;
        
        return p.titulo.equals(this.titulo) && p.anioPublicacion.equals(this.anioPublicacion);
    }
    
}
